jQuery(document).ready(function($) {
    $('.feedback-buttons button').on('click', function() {
        const query = $(this).closest('.feedback-buttons').data('query');
        const feedback = $(this).data('feedback');

        $.ajax({
            url: qa_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'qa_log_feedback',
                query: query,
                feedback: feedback,
            },
            success: function(response) {
                alert(response.data.message);
            },
            error: function() {
                alert('An error occurred while submitting feedback.');
            },
        });
    });
});