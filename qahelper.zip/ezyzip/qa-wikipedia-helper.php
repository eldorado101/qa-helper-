<?php
/**
 * Plugin Name: QA Wikipedia Helper
 * Description: A plugin to answer user questions by pulling data from Wikipedia, DuckDuckGo, and Google Knowledge Graph. Designed for dark themes.
 * Version: 1.5
 * Author: Dakota
 */
// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Create database tables on plugin activation
function qa_wikipedia_helper_create_tables() {
    global $wpdb;
    $feedback_table = $wpdb->prefix . 'qa_feedback';
    $analytics_table = $wpdb->prefix . 'qa_analytics';
    $charset_collate = $wpdb->get_charset_collate();

    // Feedback table
    $feedback_sql = "CREATE TABLE $feedback_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        query text NOT NULL,
        feedback varchar(50) NOT NULL,
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Analytics table
    $analytics_sql = "CREATE TABLE $analytics_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        query text NOT NULL,
        data_source varchar(50) NOT NULL,
        feedback varchar(50) DEFAULT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL, -- New column for user ID
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($feedback_sql);
    dbDelta($analytics_sql);
}
register_activation_hook(__FILE__, 'qa_wikipedia_helper_create_tables');

// Update the database schema if necessary
function qa_wikipedia_helper_update_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'qa_analytics';
    $column_exists = $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'user_id'");
    if (!$column_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN user_id BIGINT(20) UNSIGNED DEFAULT NULL");
    }
}
register_activation_hook(__FILE__, 'qa_wikipedia_helper_update_tables');

// Add a settings page for API keys
function qa_wikipedia_helper_add_settings_page() {
    add_options_page(
        'QA Wikipedia Helper Settings', // Page title
        'QA Wikipedia Helper',         // Menu title
        'manage_options',              // Capability required to access
        'qa-wikipedia-helper-settings',// Menu slug
        'qa_wikipedia_helper_render_settings_page' // Callback function
    );
}
add_action('admin_menu', 'qa_wikipedia_helper_add_settings_page');

// Add a top-level menu for the Analytics Dashboard
function qa_wikipedia_helper_add_top_level_menu() {
    add_menu_page(
        'Analytics Dashboard',         // Page title
        'QA Analytics',               // Menu title (visible in the admin sidebar)
        'manage_options',             // Capability required to access
        'qa-analytics-dashboard',     // Menu slug
        'qa_wikipedia_helper_render_analytics_page', // Callback function
        'dashicons-chart-bar',        // Icon (optional: use a Dashicon)
        6                             // Position in the menu (optional: 6 places it near the bottom)
    );
}
add_action('admin_menu', 'qa_wikipedia_helper_add_top_level_menu');

// Render the settings page
function qa_wikipedia_helper_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>QA Wikipedia Helper Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('qa_wikipedia_helper_settings_group');
            do_settings_sections('qa-wikipedia-helper-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Render the analytics dashboard page
function qa_wikipedia_helper_render_analytics_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'qa_analytics';

    // Fetch total queries
    $total_queries = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    // Fetch most popular queries with user info
    $popular_queries = $wpdb->get_results("
        SELECT a.query, COUNT(*) as count, u.ID as user_id, u.user_login
        FROM $table_name a
        LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
        GROUP BY a.query
        ORDER BY count DESC
        LIMIT 10
    ");

    // Fetch feedback stats with user info
    $feedback_stats = $wpdb->get_results("
        SELECT a.feedback, COUNT(*) as count, u.ID as user_id, u.user_login
        FROM $table_name a
        LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
        WHERE a.feedback IS NOT NULL
        GROUP BY a.feedback
    ");

    // Fetch data source usage with user info
    $data_source_usage = $wpdb->get_results("
        SELECT a.data_source, COUNT(*) as count, u.ID as user_id, u.user_login
        FROM $table_name a
        LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
        GROUP BY a.data_source
    ");
    ?>
    <div class="wrap">
        <h1>Analytics Dashboard</h1>
        <p><a href="<?php echo admin_url('options-general.php?page=qa-wikipedia-helper-settings'); ?>">Go to Settings</a></p>

        <h2>Total Queries: <?php echo esc_html($total_queries); ?></h2>

        <h3>Most Popular Queries</h3>
        <ul>
            <?php if (!empty($popular_queries)): ?>
                <?php foreach ($popular_queries as $query): ?>
                    <li>
                        <?php echo esc_html($query->query); ?> 
                        (<?php echo esc_html($query->count); ?>) 
                        <?php
                        if (class_exists('PeepSoUser')) {
                            $peepso_user = PeepSoUser::get_instance($query->user_id);
                            if ($peepso_user) {
                                $username = $peepso_user->get_username();
                                $profile_url = $peepso_user->get_profileurl();
                                echo 'by <a href="' . esc_url($profile_url) . '">' . esc_html($username) . '</a>';
                            } else {
                                echo 'by Unknown User';
                            }
                        } else {
                            echo 'by ' . esc_html($query->user_login);
                        }
                        ?>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No queries found.</li>
            <?php endif; ?>
        </ul>

        <h3>Feedback Stats</h3>
        <ul>
            <?php if (!empty($feedback_stats)): ?>
                <?php foreach ($feedback_stats as $stat): ?>
                    <li>
                        <?php echo esc_html($stat->feedback); ?>: 
                        <?php echo esc_html($stat->count); ?> 
                        <?php
                        if (class_exists('PeepSoUser')) {
                            $peepso_user = PeepSoUser::get_instance($stat->user_id);
                            if ($peepso_user) {
                                $username = $peepso_user->get_username();
                                $profile_url = $peepso_user->get_profileurl();
                                echo 'by <a href="' . esc_url($profile_url) . '">' . esc_html($username) . '</a>';
                            } else {
                                echo 'by Unknown User';
                            }
                        } else {
                            echo 'by ' . esc_html($stat->user_login);
                        }
                        ?>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No feedback found.</li>
            <?php endif; ?>
        </ul>

        <h3>Data Source Usage</h3>
        <ul>
            <?php if (!empty($data_source_usage)): ?>
                <?php foreach ($data_source_usage as $source): ?>
                    <li>
                        <?php echo esc_html($source->data_source); ?>: 
                        <?php echo esc_html($source->count); ?> 
                        <?php
                        if (class_exists('PeepSoUser')) {
                            $peepso_user = PeepSoUser::get_instance($source->user_id);
                            if ($peepso_user) {
                                $username = $peepso_user->get_username();
                                $profile_url = $peepso_user->get_profileurl();
                                echo 'by <a href="' . esc_url($profile_url) . '">' . esc_html($username) . '</a>';
                            } else {
                                echo 'by Unknown User';
                            }
                        } else {
                            echo 'by ' . esc_html($source->user_login);
                        }
                        ?>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No data source usage found.</li>
            <?php endif; ?>
        </ul>
    </div>
    <?php
}

// Register settings and fields
function qa_wikipedia_helper_register_settings() {
    register_setting('qa_wikipedia_helper_settings_group', 'qa_wikipedia_helper_settings');

    // Add a section for API keys
    add_settings_section(
        'qa_wikipedia_helper_api_keys_section',
        'API Keys',
        'qa_wikipedia_helper_api_keys_section_callback',
        'qa-wikipedia-helper-settings'
    );

    // Add a field for Google Knowledge Graph API key
    add_settings_field(
        'google_knowledge_graph_api_key',
        'Google Knowledge Graph API Key',
        'qa_wikipedia_helper_google_api_key_callback',
        'qa-wikipedia-helper-settings',
        'qa_wikipedia_helper_api_keys_section'
    );
}
add_action('admin_init', 'qa_wikipedia_helper_register_settings');

// Section description callback
function qa_wikipedia_helper_api_keys_section_callback() {
    echo '<p>Enter your API keys below to enable additional features.</p>';
}

// Google Knowledge Graph API key field callback
function qa_wikipedia_helper_google_api_key_callback() {
    $options = get_option('qa_wikipedia_helper_settings');
    $api_key = isset($options['google_knowledge_graph_api_key']) ? esc_attr($options['google_knowledge_graph_api_key']) : '';
    echo '<input type="text" name="qa_wikipedia_helper_settings[google_knowledge_graph_api_key]" value="' . $api_key . '" class="regular-text" placeholder="Enter your Google API key">';
}

// Shortcode to display the Q&A form
function qa_wikipedia_helper_shortcode() {
    ob_start();
    ?>
    <div id="qa-wikipedia-helper-form" class="dark-theme">
        <h3>Ask a Question</h3>
        <form method="post" id="qa-search-form">
            <input type="text" name="user_question" id="user_question" placeholder="Type your question here..." required>
            <button type="button" id="voice-search-button">🎤</button>
            <select name="data_source">
                <option value="duckduckgo" selected>DuckDuckGo</option>
                <option value="wikipedia">Wikipedia</option>
                <option value="google_kg">Google Knowledge Graph</option>
            </select>
            <input type="submit" name="submit_question" value="Submit">
        </form>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_question'])) {
            $user_question = sanitize_text_field($_POST['user_question']);
            $data_source = sanitize_text_field($_POST['data_source']);

            // Ensure the user is logged in
            if (!is_user_logged_in()) {
                echo '<p>You must be logged in to use this feature.</p>';
                return;
            }

            // Get the current user ID (WordPress ID)
            $user_id = get_current_user_id();

            // Log the query
            global $wpdb;
            $table_name = $wpdb->prefix . 'qa_analytics';
            $result = $wpdb->insert(
                $table_name,
                [
                    'query' => $user_question,
                    'data_source' => $data_source,
                    'user_id' => $user_id, // Log the user ID
                ]
            );
            if ($result === false) {
                error_log('Database insert failed: ' . $wpdb->last_error);
            } else {
                error_log('Query logged successfully.');
            }

            switch ($data_source) {
                case 'duckduckgo':
                    $answer = qa_wikipedia_helper_fetch_from_duckduckgo($user_question);
                    break;
                case 'google_kg':
                    $answer = qa_wikipedia_helper_fetch_from_google_kg($user_question);
                    break;
                default:
                    $answer = qa_wikipedia_helper_fetch_from_wikipedia($user_question);
            }
            echo '<h4>Answer:</h4>';
            if ($answer) {
                echo '<p>' . $answer . '</p>';
            } else {
                echo '<p>No matching answer found.</p>';
            }
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('qa_wikipedia_helper', 'qa_wikipedia_helper_shortcode');

// Fetch data from Wikipedia's API
function qa_wikipedia_helper_fetch_from_wikipedia($question) {
    $cache_key = 'wiki_answer_' . md5($question);
    $answer = get_transient($cache_key);
    if (false === $answer) {
        $question = preg_replace('/[^a-zA-Z0-9\s]/', '', $question);
        $question = trim($question);
        $api_url = 'https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=' . urlencode($question) . '&format=json';
        $response = wp_remote_get($api_url);
        if (is_wp_error($response)) {
            return false;
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['query']['search'][0]['title'])) {
            $title = str_replace(' ', '_', $body['query']['search'][0]['title']);
            $title = urlencode($title);
            $summary_url = "https://en.wikipedia.org/api/rest_v1/page/summary/$title";
            $summary_response = wp_remote_get($summary_url);
            if (!is_wp_error($summary_response)) {
                $summary_body = json_decode(wp_remote_retrieve_body($summary_response), true);
                if (isset($summary_body['extract'])) {
                    $answer = $summary_body['extract'];
                    set_transient($cache_key, $answer, DAY_IN_SECONDS);
                } else {
                    $article_url = 'https://en.wikipedia.org/wiki/' . urlencode($title);
                    $answer = 'No summary available. <a href="' . esc_url($article_url) . '" target="_blank">Read the full article on Wikipedia</a>.';
                }
            }
        } else {
            $search_url = 'https://en.wikipedia.org/wiki/Special:Search?search=' . urlencode($question);
            $answer = 'No exact answer found. <a href="' . esc_url($search_url) . '" target="_blank">Search Wikipedia</a> for more information.';
        }
    }
    return $answer;
}

// Fetch data from DuckDuckGo's Instant Answer API
function qa_wikipedia_helper_fetch_from_duckduckgo($question) {
    $cache_key = 'ddg_answer_' . md5($question);
    $cached_result = get_transient($cache_key);
    if ($cached_result) {
        return $cached_result;
    }

    $url = "https://api.duckduckgo.com/";
    $params = [
        'q' => $question,
        'format' => 'json',
    ];
    $response = wp_remote_get(add_query_arg($params, $url));
    if (is_wp_error($response)) {
        return '<p class="error">Error fetching data from DuckDuckGo.</p>';
    }
    $body = json_decode(wp_remote_retrieve_body($response), true);

    $output = '';
    if (!empty($body['AbstractText'])) {
        $output .= '<p>' . esc_html($body['AbstractText']) . '</p>';
    } elseif (!empty($body['RelatedTopics'])) {
        $output .= '<ul>';
        foreach ($body['RelatedTopics'] as $topic) {
            $output .= '<li>' . esc_html($topic['Text']) . '</li>';
        }
        $output .= '</ul>';
    } else {
        $output = '<p>No results found on DuckDuckGo.</p>';
    }

    // Add image if available
    if (!empty($body['Image'])) {
        $image_url = 'https://duckduckgo.com' . $body['Image']; // Convert relative URL to absolute
        $output .= '<img src="' . esc_url($image_url) . '" alt="DuckDuckGo Image">';
    } else {
        // Fallback placeholder image
        $placeholder_image = plugins_url('placeholder.jpg', __FILE__);
        $output .= '<img src="' . esc_url($placeholder_image) . '" alt="Placeholder Image">';
    }

    // Add feedback buttons
    $output .= '<div class="feedback-buttons" data-query="' . esc_attr($question) . '">';
    $output .= '<button data-feedback="positive">👍</button>';
    $output .= '<button data-feedback="negative">👎</button>';
    $output .= '</div>';

    set_transient($cache_key, $output, DAY_IN_SECONDS);
    return $output;
}

// Fetch data from Google Knowledge Graph API
function qa_wikipedia_helper_fetch_from_google_kg($question) {
    $options = get_option('qa_wikipedia_helper_settings');
    $api_key = isset($options['google_knowledge_graph_api_key']) ? $options['google_knowledge_graph_api_key'] : '';
    if (empty($api_key)) {
        return '<p class="error">Google Knowledge Graph API key is not set.</p>';
    }

    $url = "https://kgsearch.googleapis.com/v1/entities:search";
    $params = [
        'query' => $question,
        'key' => $api_key,
        'limit' => 5,
        'languages' => 'en',
    ];
    $response = wp_remote_get(add_query_arg($params, $url));
    if (is_wp_error($response)) {
        return '<p class="error">Error fetching data from Google Knowledge Graph.</p>';
    }
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!empty($body['itemListElement'])) {
        $results = '<ul>';
        foreach ($body['itemListElement'] as $item) {
            $results .= '<li>';
            $results .= '<strong>' . esc_html($item['result']['name']) . '</strong>';
            if (!empty($item['result']['description'])) {
                $results .= ': ' . esc_html($item['result']['description']);
            }
            $results .= '</li>';
        }
        $results .= '</ul>';
        return $results;
    } else {
        return '<p>No results found on Google Knowledge Graph.</p>';
    }
}

// Enqueue custom CSS and JavaScript
function qa_wikipedia_helper_enqueue_scripts() {
    // Check if the shortcode is used on the current page
    if (has_shortcode(get_the_content(), 'qa_wikipedia_helper')) {
        // Enqueue styles and scripts only when the shortcode is present
        wp_enqueue_style('qa-wikipedia-helper-style', plugins_url('style.css', __FILE__));
        wp_enqueue_script('qa-wikipedia-helper-ajax', plugins_url('ajax.js', __FILE__), ['jquery'], null, true);
        wp_localize_script('qa-wikipedia-helper-ajax', 'qa_ajax_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);
        wp_enqueue_script('qa-wikipedia-helper-voice', plugins_url('voice.js', __FILE__), [], null, true);
    }
}
add_action('wp_enqueue_scripts', 'qa_wikipedia_helper_enqueue_scripts');

// AJAX handler for feedback
function qa_wikipedia_helper_log_feedback() {
    $query = sanitize_text_field($_POST['query']);
    $feedback = sanitize_text_field($_POST['feedback']);

    // Log feedback to the database
    global $wpdb;
    $table_name = $wpdb->prefix . 'qa_analytics';
    $wpdb->update(
        $table_name,
        ['feedback' => $feedback],
        ['query' => $query]
    );

    wp_send_json_success(['message' => 'Thank you for your feedback!']);
}
add_action('wp_ajax_qa_log_feedback', 'qa_wikipedia_helper_log_feedback');
add_action('wp_ajax_nopriv_qa_log_feedback', 'qa_wikipedia_helper_log_feedback');