document.addEventListener('DOMContentLoaded', function () {
    const voiceButton = document.getElementById('voice-search-button');
    const inputField = document.getElementById('user_question');

    // Check if the elements exist in the DOM
    if (!voiceButton) {
        console.error('Element with ID "voice-search-button" not found.');
        return;
    }
    if (!inputField) {
        console.error('Element with ID "user_question" not found.');
        return;
    }

    // Check if the Web Speech API is supported
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        voiceButton.style.display = 'none'; // Hide the button if the API is not supported
        console.error('Web Speech API is not supported in this browser.');
        return;
    }

    // Use the appropriate constructor based on browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    // Configure the recognition settings
    recognition.continuous = false; // Stop listening after the first result
    recognition.interimResults = false; // Do not show interim results
    recognition.lang = 'en-US'; // Set the language to English (US)

    // Start recognition when the microphone button is clicked
    voiceButton.addEventListener('click', function () {
        recognition.start();
        voiceButton.textContent = 'Listening...';
    });

    // Handle successful recognition results
    recognition.onresult = function (event) {
        if (!event.results || !event.results[0]) {
            console.error('No results found in speech recognition.');
            voiceButton.textContent = '🎤'; // Reset the button text
            return;
        }
        const transcript = event.results[0][0].transcript; // Get the recognized text
        inputField.value = transcript; // Populate the input field with the spoken query
        voiceButton.textContent = '🎤'; // Reset the button text
    };

    // Handle errors during recognition
    recognition.onerror = function (event) {
        console.error('Speech recognition error:', event.error);
        console.error('Error message:', event.message);
        voiceButton.textContent = '🎤'; // Reset the button text
        alert('An error occurred while using voice search. Please try again.');
    };

    // Handle the end of recognition
    recognition.onend = function () {
        voiceButton.textContent = '🎤'; // Reset the button text
    };
});